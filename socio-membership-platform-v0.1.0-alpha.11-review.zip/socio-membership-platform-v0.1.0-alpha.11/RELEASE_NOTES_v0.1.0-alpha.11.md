# Socio v0.1.0-alpha.11

## What's new

- Added an installable PWA shell with Android and iOS home-screen metadata, app icons, and installation guidance.
- The service worker caches only static app assets. Authenticated pages and other application data are never cached for offline use.
- Added local Gmail SMTP setup instructions. When SMTP is configured, Socio sends actual confirmation email; terminal links remain a localhost-only fallback.
- Fixed loyalty tenure across renewals: monthly renewals no longer reset the member's original start day, and a reward can trigger when the support milestone coincides with a billing boundary.
- Expanded workflow coverage for registration and one-time email confirmation, member application through organization review and simulated payment, event/offer publishing and detail access, and loyalty gifts across renewals.

## Verification

- `pytest`: 21 passed.
- Payment processing remains simulated. No real money is collected.
- SMS verification and App Store / Play Store native packages are not included in this prerelease.
