# Socio v0.1.0-alpha.6

This prerelease builds on alpha.5 by adding a memorable private entry point for platform staff.

## Changes in this prerelease

- Added `/platform-admin` as a dedicated platform-team entry URL. Signed-out visitors are sent to the platform-admin sign-in page; an authenticated platform administrator is sent to the dashboard.
- Kept the entry point out of public navigation. Members and organization administrators do not see a platform-admin sign-in link, and admin pages continue to require the platform-admin role.
- Updated the local walkthrough to use the new entry URL.

## Local use

With the local app running on its default guided port, open `http://127.0.0.1:5001/platform-admin`. Replace `5001` if you selected a different port. Sign in with the platform administrator created during local setup.

## Scope

This is a private convenience route, not a replacement for authentication or role-based access checks. The app remains an early local prerelease. Payments remain simulated; no real money moves and HNB is not connected. See the alpha.5 notes for the current feature summary and production-readiness backlog.
