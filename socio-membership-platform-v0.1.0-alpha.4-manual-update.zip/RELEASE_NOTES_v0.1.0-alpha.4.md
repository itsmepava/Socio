# Socio v0.1.0-alpha.4

This is the next prerelease after alpha.1 through alpha.3. It packages the latest local app updates under alpha.4 so the GitHub history and release sequence stay in order. This is a local testing build using synthetic data only.

## What changed

- Added a searchable organization gallery with organization details, published plan comparisons, benefits, and current offers.
- Added organization-managed offers. Offers are informational and do not change simulated checkout prices.
- Added email ownership confirmation with single-use, hashed tokens that expire after 24 hours. Confirmation pages require an explicit action to avoid link scanners consuming tokens.
- Added email-confirmation resend pages, resend cooldowns, and limits on organization registration to reduce automated signup and email abuse.
- Added opt-in local email preview mode. With `DEV_EMAIL_PREVIEW=1` and a localhost `PUBLIC_BASE_URL`, confirmation links appear in the Flask server console; verification is still required. SMTP remains the normal email delivery method when configured. Never enable preview on a public server.
- Hardened roster invitation links to use `PUBLIC_BASE_URL`, marked authenticated pages as non-cacheable, and documented secure cookies and HSTS for HTTPS deployments.
- Includes the existing role-based admin, organization, and member workspaces; welcome screens; plan setup; membership applications; roster invitations and CSV import; and one member account across multiple organizations.

## Local setup

Follow the Windows instructions in `README.md`. For local signup without an email provider, set `DEV_EMAIL_PREVIEW=1`; open the confirmation link printed in the Flask server console. Keep `SESSION_COOKIE_SECURE=0` for local HTTP. Use synthetic data only.

## Security and limitations

Socio remains a single Flask application with browser sessions and a local SQLite database. It has no public JSON API, microservices, API-key management, or service-to-service tokens. The application has role-gated pages, organization-scoped management, CSRF protection, Argon2 password hashing, request limits, and hashed one-time invitation and confirmation tokens, but it has not completed an independent security review.

Payments, refunds, offline-payment entries, and the day/renewal clock are simulated; no money moves and HNB is not connected. SMTP delivery requires provider credentials unless using local email preview. Before consumer use or GCP hosting, complete tenant-authorization tests and security review, add account recovery and platform-admin MFA, move rate limits to shared persistent storage, configure HTTPS, managed secrets, production database backups and monitoring, and define least-privilege service identities. Do not use real member or payment data in this prerelease.