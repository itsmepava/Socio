# Socio v0.1.0-alpha.5

This local prerelease builds on the alpha.4 version uploaded to GitHub. It keeps the payment provider simulated and adds the review and privacy steps needed to make the demo clearer to members and safer to operate locally.

## Changes since alpha.4

- Removed the platform-admin sign-in card from the public home page. Public navigation only shows member and organization entry points. Platform-admin pages remain protected by the platform-admin role; the local sign-in URL is documented for the platform team and is not linked from public pages.
- Added a required pre-payment review showing the organization, plan, server-calculated amount in LKR, billing period, expected simulated start/end, and cancellation terms. A member must acknowledge the simulated-payment terms before opening the simulated checkout. Payment routes still verify the signed-in member owns the payment.
- Added opt-in, localhost-only email preview mode. With `DEV_EMAIL_PREVIEW=1`, new confirmation links appear in the local Flask server console. Confirmation still requires the single-use verification link; preview mode does not verify accounts automatically.
- Hardened roster invitation URL generation to use configured `PUBLIC_BASE_URL`, added email-resend cooldowns and organization-registration rate limits, and set authenticated pages to `Cache-Control: no-store`.
- Added secure-cookie and HSTS behavior when `SESSION_COOKIE_SECURE=1`, and updated local setup and deployment notes.
- Updated the local guide to explain the hidden platform-admin entry point and new membership payment-review step.

## Local testing

Use `start-local.ps1` in PowerShell for guided setup on port 5001. It can create optional Colombo Chess Club sample data and prompt for a platform-admin account on a fresh database. Email preview is enabled only for the local `127.0.0.1` URL by the script. See `README.md` for manual setup and the end-to-end flow.

## Scope and limitations

Membership applications, accounts, organization approval, plans, offers, and the demo ledger are stored in the local app database. Email verification can use the local preview or configured SMTP. Payment outcomes, renewals, refunds, offline-payment records, and the day clock are simulations; no money moves and HNB is not connected. The payment review uses the demo clock, not real calendar dates.

Socio remains a local prerelease, not a consumer-ready production service. Before GCP launch it still needs production database migrations and backups, shared rate limiting, account recovery and platform-admin MFA, broader automated tenant-authorization and payment-state tests, operational monitoring, and independent security/recovery review. See the alpha.4 notes for the earlier security and launch backlog.
