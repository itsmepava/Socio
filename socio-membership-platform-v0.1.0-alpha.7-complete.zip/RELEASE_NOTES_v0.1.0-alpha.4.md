# Socio v0.1.0-alpha.4

This prerelease adds organization discovery, informational offers, and email ownership confirmation to the local demo. Payments remain simulated. This is not a production deployment.

## What changed

- Added a searchable organization gallery. Members can search organizations, published plans and benefits, and current offers, then open a public organization page to compare plans.
- Added organization-managed offers with a type, description, optional plan, and simulated start/end days. Offers appear in the gallery and public organization page only while active. They do not discount or otherwise modify checkout prices.
- Added email confirmation for newly registered organization administrators and members, including members who claim roster invitations. Confirmation links are single-use, stored as hashes, and expire after 24 hours. Opening a link requires a separate confirm click, so automatic link scanners do not consume it.
- Added a resend-confirmation page and prevented unconfirmed accounts from signing in. New member applications remain pending and are available after the member confirms their address.
- Added configurable generic SMTP settings and local database migration for the verification flag. Existing demo accounts are preserved as verified so they can still sign in.
- Updated the organization workspace, sign-in pages, local setup guide, and responsive light/dark styling.
- This build also includes the previously developed welcome screens and member invitation/roster-import flow, support for one member account across multiple organizations, and the platform-admin sign-in entry point.

## Local email setup

Before creating new member or organization accounts, configure SMTP in the environment where Flask runs:

```powershell
$env:MAIL_SERVER = 'your-smtp-host'
$env:MAIL_PORT = '587'
$env:MAIL_USERNAME = 'your-smtp-username'
$env:MAIL_PASSWORD = 'your-smtp-password'
$env:MAIL_FROM = 'Socio <noreply@your-domain.example>'
$env:MAIL_USE_TLS = '1'
$env:MAIL_USE_SSL = '0'
$env:PUBLIC_BASE_URL = 'http://127.0.0.1:5000'
```

Use the mail provider's actual SMTP host, sender address, and credentials. Never commit real credentials. On a hosted environment, set `PUBLIC_BASE_URL` to the HTTPS site URL. Without valid SMTP configuration, new accounts stay locked and the confirmation page explains that delivery needs setup; a site administrator can then configure SMTP and the user can request another link.

## Security status

This remains one Flask application. It does not expose a public JSON API and does not yet have microservices or service-to-service tokens. Current safeguards include Argon2 password hashing, role-protected routes, organization-scoped record lookups in management routes, CSRF protection for forms, per-IP request limits, HttpOnly/SameSite session cookies, session nonce checks, security response headers, and hashed one-time invitation and email-verification tokens.

These controls are a foundation, not a completed security review. Before external users, public APIs, or GCP hosting, the remaining security work includes:

1. Review every route that reads or changes an ID-addressed object for tenant/organization ownership and property-level authorization; add cross-organization authorization checks to the automated test suite.
2. Add account recovery, admin MFA, stronger session lifecycle controls, and persistent shared rate-limit storage. The current limiter uses in-memory storage and resets with the process.
3. Define each public API's allowed caller, data, role/scope, rate limit, versioning, and audit event. Use short-lived, narrowly scoped credentials with rotation and revocation; do not embed long-lived API secrets in browser code.
4. If services are split later, assign each workload its own identity and minimum permissions, keep internal services off the public network, and authenticate service-to-service calls. Do not reuse end-user sessions as service credentials.
5. For GCP, use an attached least-privilege workload service account for VM access to Google Cloud resources, store application secrets in a managed secret store, and require HTTPS, database backups, monitoring, and incident/recovery procedures.
6. Complete an independent security review and fix the findings before using real member data or any real payment provider.

The API access guidance follows the authorization risks in the [OWASP API Security Top 10](https://api-security.owasp.org/editions/2023/en/0x11-t10/). Google Cloud's [workload identity guidance](https://docs.cloud.google.com/iam/docs/workload-identities) describes per-workload identities and IAM-based permissions.

## Limitations

- No public API, API-key management, microservices, MFA, password reset, real email bounce tracking, real payments, refunds, or payouts are included.
- SMTP must be configured by the local operator to deliver confirmation messages.
- This prerelease is for local testing with synthetic data only.
