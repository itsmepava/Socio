# Socio v0.1.0-alpha.7

This prerelease adds a public product overview and gives organizations more control over how people apply for membership.

## Changes in this prerelease

- Added an **About Socio** page describing the platform for members, organizations, and the platform team.
- Restored a visible platform-admin shortcut for the local development setup. It is off by default in the app configuration and should stay off on a public deployment. Platform-admin pages still require a platform-admin account.
- Added organization settings to require manual application review or allow open applications.
- Added optional recommendation/supporting details and custom application instructions.
- Added an organization application inbox with approve/decline actions and optional decision notes. Approval unlocks the existing simulated payment flow; a declined applicant can revise and resubmit.
- Made organization-issued invitations count as approval, and guarded payment review, simulated payment, and offline join-payment routes against bypassing required approval.
- Updated local setup and product documentation.

## Important scope notes

- Organizations must verify school, alumni, or other eligibility claims themselves. There is no school roster or identity verification integration.
- Recommendation information is collected as text in this prerelease. Secure letter-file upload, malware scanning, audit access, and retention controls are not included.
- Payments remain simulated; this prerelease does not charge or transfer real money.

## Local use

Run `start-local.ps1` from the extracted project folder. Platform admin is visible in this local development setup. Organization administrators can configure **Membership eligibility** in their workspace and review applications there.
