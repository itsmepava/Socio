# Socio v0.1.0-alpha.10

## What's new

- Members can open event cards to view a dedicated page with the full event description, date, venue, poster, and organization link.
- Members can open offer cards to view the full offer description, eligible plan, and simulated offer period.
- Gallery previews and organization public-page cards link to these detail pages.
- Event and offer detail URLs only show currently public items; archived, expired, unpublished, or non-approved organization content returns not found.
- Detail pages link back to the organization and membership plans.

## Local preview notes

- Payments remain simulated; no money is collected.
- Event dates use the local calendar, while offer availability follows the simulated day.
