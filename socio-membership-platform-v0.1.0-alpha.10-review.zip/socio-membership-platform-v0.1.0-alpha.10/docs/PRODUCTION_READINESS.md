# Socio production readiness

Socio is a local development prerelease. The code now supports the main demonstration workflows, but the current local setup is not yet a production service. This checklist separates capabilities already present from work that must be completed before real consumers depend on it.

## Present in the prototype

- Separate platform administrator, organization administrator, and member roles with scoped organization workspaces.
- Password hashing, email confirmation, session invalidation, CSRF protection, role checks, rate limits, and security response headers.
- Organization discovery, plans, offers, applications, manual approval, recommendation details, and member invitations.
- Organization logo upload with format and size limits, server-side image decoding and re-encoding, and randomized server-generated filenames.
- Organization event publishing with optional poster uploads, plus one-time simulated loyalty membership-day gifts.
- Configurable SMTP for confirmation email and local-only email preview.
- A lightweight database-backed `/healthz` endpoint for host health checks.
- Simulated payments only. No real money is collected.

## Required before a consumer launch

1. **Production hosting:** Deploy behind HTTPS on GCP, use a production WSGI server, managed secrets, least-privilege service accounts, secure cookies, production host/URL settings, and keep the platform-admin shortcut hidden.
2. **Persistent data:** Move from local SQLite to a managed production database, add versioned schema migrations, configure automated backups, and rehearse a restore.
3. **Shared files:** Move organization logos and event posters from local instance storage to durable managed object storage with lifecycle/backup settings.
4. **Abuse controls:** Replace in-memory rate-limit storage with shared storage and confirm limits across multiple app instances.
5. **Account safety:** Add account recovery, platform-admin MFA, session/device management, and account security notifications.
6. **Verification and eligibility:** Configure dependable production email delivery. Decide how organizations will verify school enrollment, alumni status, recommendation sources, and any other eligibility requirements.
7. **Operational readiness:** Add health monitoring, error reporting, structured logs, uptime alerts, incident response, data retention/deletion policies, and a privacy notice/terms before onboarding real users.
8. **Security and quality review:** Review tenant isolation and authorization, run security checks, test supported browsers and mobile layouts, and verify backup/recovery and deployment rollback.

Real payment processing is intentionally out of scope for this stage. If it is added later, confirm the provider, settlement model, refund process, and compliance requirements first; do not store card data in Socio.
