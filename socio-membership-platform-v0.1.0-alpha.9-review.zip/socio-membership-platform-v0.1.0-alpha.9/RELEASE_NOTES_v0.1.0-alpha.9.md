# Socio v0.1.0-alpha.9

## What's new

- Organization administrators can enable a one-time loyalty gift for active members, choose an active-support milestone, and set the no-charge membership extension.
- Organizations can publish upcoming events with a date, location, details, and an optional poster image.
- Upcoming events appear in the member organization gallery and on each public organization page. Members can search event names, details, and venues.
- Image uploads are decoded and re-encoded on the server with format, pixel, and output-size limits.
- Updated local setup and production-readiness notes to cover these features.

## Local preview notes

- Payments remain simulated; no money is collected.
- Loyalty awards are applied by the simulated clock when an eligible active membership reaches its configured milestone.
- Images are stored in local instance storage for this preview. A hosted GCP deployment still needs durable object storage for logos and posters.
- Existing local SQLite data is upgraded with the new fields when the application starts.
